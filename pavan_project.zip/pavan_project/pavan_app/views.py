from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.decorators import login_required
from .models import Task
from django.views.decorators.csrf import csrf_exempt
from django.shortcuts import get_object_or_404


# Register View
def user_register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = UserCreationForm()
    return render(request, 'pavan_app/register.html', {'form': form})

# Login View
def user_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            return redirect('task-list')
        else:
            return render(request, 'pavan_app/login.html', {'error': 'Invalid credentials'})
    return render(request, 'pavan_app/login.html')

# Logout View
def user_logout(request):
    logout(request)
    return redirect('login')

# Task List View (only for logged-in users)
@login_required(login_url='login')
@csrf_exempt
def task_list(request):
    if request.method == 'POST':
        title = request.POST.get('title')
        description = request.POST.get('description')
        if title:
            Task.objects.create(
                user=request.user,
                title=title,
                description=description,
            )
            return redirect('task-list')

    tasks = Task.objects.filter(user=request.user)
    return render(request, 'pavan_app/task_list.html', {'tasks': tasks})

@login_required(login_url='login')
def delete_task(request, task_id):
    task = get_object_or_404(Task, id=task_id, user=request.user)
    task.delete()
    return redirect('task-list')

@login_required(login_url='login')
def complete_task(request, task_id):
    task = get_object_or_404(Task, id=task_id, user=request.user)
    task.complete = True
    task.save()
    return redirect('task-list')
