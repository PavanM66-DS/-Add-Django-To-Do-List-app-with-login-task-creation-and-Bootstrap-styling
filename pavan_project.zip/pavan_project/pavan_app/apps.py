from django.apps import AppConfig


class PavanAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pavan_app'
